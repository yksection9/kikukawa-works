# セットアップ依頼文 v2（利用者が Claude に貼る。1回だけ）

利用者が手でやること（3つだけ）
1. supabase.com で無料アカウントを作る（Google ログインで可）
2. Claude の「コネクタ」で Supabase を接続する（ブラウザで承認するだけ）
3. cc-window-kit のフォルダを Claude に接続する

----- ここから貼る -----
Thread Status for Claude のセットアップをお願いします。私への確認なしで、次の順に進めてください。失敗したら原因を1〜2文で教えてください。鍵や秘密は会話に書き出さないでください。
1. 診断: Supabase コネクタと cc-window-kit フォルダが使えるか確認する。使えなければ、足りないものを1行で伝えて止まる。
2. Supabase の organization を確認し、プロジェクト一覧を見る。「cc-window」という名前のプロジェクトがあればそれを使う。無ければ無料プランで新規作成する（料金が 0 であることを確認。0 でなければ止まって私に聞く）。
3. 窓の鍵として、ランダムな40文字の英数字を作る（会話には出さない）。
4. cc-window-kit/setup/schema.sql の __WINDOW_KEY__ をその鍵に置き換えて、execute_sql で実行する。
5. プロジェクトの URL と公開(anon)の鍵を取得し、cc-window-kit フォルダと同じ階層の claude_state/supabase_read.json に {"url":…, "key":…, "header_key":…} で保存する（claude_state フォルダが無ければ作る）。
6. 次に私が貼る「ずっと使う指示」の文面（__SUPABASE_PROJECT_ID__ を実際のIDに置き換えたもの）を、cc-window-kit/setup/my_instruction.md に保存し、画面にも出す。
7. 動作確認: テスト行を1つ upsert し、REST(GET)で読み戻せるか確かめる。確認できたらテスト行を削除する。
8. 最後に「できたこと／私が次にやること」を3行以内で報告する。
----- ここまで -----

次に利用者がやること（1回だけ）
Claude の設定（プロファイル→好み/Preferences）に、my_instruction.md の文面を貼る。
→ プロジェクトごとに貼る必要はない（全プロジェクトに効く。※この点は実機で確認済みではない。効かないプロジェクトだけ「プロジェクトの指示」に貼る）。

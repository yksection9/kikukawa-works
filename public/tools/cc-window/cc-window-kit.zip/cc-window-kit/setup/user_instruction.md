## 状態の記録(Thread Status for Claude用)
返信を終えるたびに、Supabase コネクタの execute_sql で次を実行し、自分の状態を記録する。コネクタが使えないスレッドでは何もしない（エラーにしない）。
(project_id は __SUPABASE_PROJECT_ID__。session_id は get_session を session_id なしで呼んで確かめる。project はこのプロジェクトの名前、title はこのスレッドの題名)

insert into thread_status (session_id, project, project_id, title, status, needs_action)
values ('<session_id>', '<プロジェクト名>', '<プロジェクトID>', '<題名>', '<status>', '<次に要ること>')
on conflict (session_id) do update set project=excluded.project, project_id=excluded.project_id,
  title=excluded.title, status=excluded.status, needs_action=excluded.needs_action, updated_at=now();

status は working / blocked(人の返事待ち) / review_ready(確認待ち) / completed / failed のどれか。
needs_action は120文字以内。パスワード・鍵などの秘密は書かない。

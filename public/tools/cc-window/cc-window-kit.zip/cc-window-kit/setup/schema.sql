-- 見える化ウインドウ: スレッド状態テーブル(利用者自身の Supabase に作る)
-- __WINDOW_KEY__ は、セットアップ時にランダムな長い文字列(24文字以上)に置き換える。他人に見せない。
create table if not exists public.thread_status (
  session_id   text primary key,
  project      text not null,
  project_id   text,
  title        text,
  status       text not null check (status in ('working','blocked','review_ready','completed','failed')),
  needs_action text,
  updated_at   timestamptz not null default now()
);
comment on table public.thread_status is '見える化ウインドウ用: 各スレッドが、ターンの終わりに自分の状態を1行 upsert する。';

alter table public.thread_status enable row level security;

-- 小窓は anon の鍵 + ヘッダー x-window-key で読む(読み取り専用)。書き込みは Claude(コネクタ)だけ。
drop policy if exists "window read with header key" on public.thread_status;
create policy "window read with header key" on public.thread_status
  for select to anon
  using (((current_setting('request.headers', true))::json ->> 'x-window-key') = '__WINDOW_KEY__');

"""folder_map.py - 指定フォルダの構造を、クリックで開けるツリー図(HTML)にする。

使い方:
    python folder_map.py [フォルダ] [--out 出力.html] [--no-skip] [--skip 名前 ...] [--no-open]
    python folder_map.py [フォルダ] --serve [--port 8765]   常時表示用。自分のPCだけで見られる簡易サーバーを立てる
フォルダを省略すると、このツールを置いた場所(tools フォルダの中、または code という名前なら、その1つ上)を調べる。
画面の「フォルダを選ぶ」ボタンで、いつでも別のフォルダに切り替えられる。
読み取り専用。調べたフォルダには何も書き込まない(--serve でも書き込まない)。
"""
import argparse
import json
import os
import subprocess
import sys
import threading
import time
from collections import Counter
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

# 数が多すぎて図が読めなくなる定番フォルダ。中身は調べず「省略」と表示する。
DEFAULT_SKIP = {'node_modules', '.git', '__pycache__', '.venv', 'venv', '.next', '.cache', 'dist', 'build'}
TOP_EXT = 8
MAX_ENTRIES = 60000  # これを超えるほど大きいフォルダ(Cドライブ全体など)は、途中までで打ち切る
MARK = '/*__DATA__*/null'

PICK_CODE = (
    "import tkinter as tk\n"
    "from tkinter import filedialog\n"
    "r = tk.Tk()\n"
    "r.withdraw()\n"
    "r.attributes('-topmost', True)\n"
    "print(filedialog.askdirectory(title='調べるフォルダを選んでください') or '')\n"
)


def default_root(here):
    return here.parents[1] if here.parent.name.lower() == 'tools' or here.name.lower() == 'code' else here.parent


def scan(path, skip, budget, name=None):
    node = {'n': name if name is not None else os.path.basename(path), 'd': [], 'f': [],
            'fc': 0, 'sz': 0, 'mt': 0, '_ex': Counter()}
    try:
        entries = sorted(os.scandir(path), key=lambda e: e.name.lower())
    except OSError:
        return node
    for e in entries:
        if budget[0] <= 0:
            budget[1] = True
            break
        budget[0] -= 1
        try:
            if e.is_dir(follow_symlinks=False):
                if e.name in skip:
                    node['d'].append({'n': e.name, 'skip': 1, 'd': [], 'f': [], 'fc': 0, 'sz': 0, 'mt': 0, '_ex': Counter()})
                else:
                    node['d'].append(scan(e.path, skip, budget))
            elif e.is_file(follow_symlinks=False):
                st = e.stat(follow_symlinks=False)
                node['f'].append([e.name, st.st_size, int(st.st_mtime)])
                ext = os.path.splitext(e.name)[1].lower() or '(拡張子なし)'
                node['_ex'][ext] += 1
        except OSError:
            continue
    node['fc'] = len(node['f'])
    node['sz'] = sum(f[1] for f in node['f'])
    node['mt'] = max([f[2] for f in node['f']], default=0)
    for c in node['d']:
        node['fc'] += c['fc']
        node['sz'] += c['sz']
        node['mt'] = max(node['mt'], c['mt'])
        node['_ex'].update(c['_ex'])
    return node


def finish(node):
    node['ex'] = [[k, v] for k, v in node.pop('_ex').most_common(TOP_EXT)]
    for c in node['d']:
        finish(c)


def count(node):
    return 1 + sum(count(c) for c in node['d'])


def build(root, skip):
    """フォルダを調べて、HTMLに埋め込む/data.jsonで返すJSON文字列と、集計を返す。"""
    budget = [MAX_ENTRIES, False]
    tree = scan(root, skip, budget, name=os.path.basename(root) or root)
    finish(tree)
    tree['root'] = root
    tree['truncated'] = budget[1]
    try:  # プロジェクトの状態の記録(root直下の project_status.json)。読めなくても、図は出す
        import project_status
        project_status.attach(tree)
    except Exception as e:
        tree['ps'] = {'found': False, 'warn': ['状態の記録を読めませんでした(%s)' % str(e)[:60]]}
    payload = json.dumps(tree, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    return payload, tree


def pick_folder():
    """フォルダ選択ダイアログをこのPC上で開き、選ばれたパスを返す(キャンセルは空文字)。"""
    env = dict(os.environ, PYTHONIOENCODING='utf-8')
    r = subprocess.run([sys.executable, '-c', PICK_CODE], capture_output=True, env=env, timeout=600)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.decode('utf-8', 'replace')[-200:])
    p = r.stdout.decode('utf-8', 'replace').strip()
    return os.path.normpath(p) if p else ''


NAV_TABS = {'home', 'files', 'files/recent', 'files/folders', 'files/map', 'usage', 'safety', 'safety/diag', 'safety/rules', 'safety/connect', 'safety/threads', 'commands'}


def serve(default, skip, here, port):
    app_path = here / 'app.html'
    nav = {'seq': 0, 'tab': ''}  # window.py が「この画面に切り替えて」と頼むための伝言板(画面側が数秒ごとに見る)

    class Handler(BaseHTTPRequestHandler):
        def reply(self, code, body, ctype):
            data = body.encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type', ctype)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(data)

        def reply_bytes(self, code, data, ctype):
            self.send_response(code)
            self.send_header('Content-Type', ctype)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-cache')  # 取り直した画像がすぐ反映されるように(毎回、更新を確かめる。ローカルなので軽い)
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(data)

        def redirect(self, where):
            self.send_response(302)
            self.send_header('Location', where)
            self.send_header('Content-Length', '0')
            self.end_headers()

        def do_GET(self):
            # 他のサイトから勝手に呼ばれないよう、宛先が localhost のものだけ受け付ける
            if self.headers.get('Host', '').split(':')[0] not in ('localhost', '127.0.0.1'):
                self.send_error(403)
                return
            url = urlparse(self.path)
            route = url.path
            want = (parse_qs(url.query).get('root') or [''])[0]
            root = os.path.abspath(want) if want and os.path.isdir(want) else default
            html, js = 'text/html; charset=utf-8', 'application/json; charset=utf-8'
            if route in ('/usage', '/commands'):  # 旧版の画面。1つの窓にまとめたので、該当の画面へ転送する
                self.redirect('/#' + route[1:])
            elif route == '/nav':
                tab = (parse_qs(url.query).get('tab') or [''])[0]
                if self.headers.get('X-FM') != '1' or tab not in NAV_TABS:
                    self.send_error(403)
                    return
                nav['seq'] += 1
                nav['tab'] = tab
                self.reply(200, json.dumps(nav), js)
            elif route == '/nav.json':
                self.reply(200, json.dumps(nav), js)
            elif route == '/usage.json':
                import token_usage
                self.reply(200, json.dumps(token_usage.compute()), js)
            elif route == '/activity.json':
                import activity
                repos = [r.strip() for r in (parse_qs(url.query).get('gh') or [''])[0].split(',') if r.strip()]
                self.reply(200, json.dumps(activity.compute(repos), ensure_ascii=False), js)
            elif route == '/connectors.json':  # Claude が保存した、連携サービスの一覧(名前・状態・ツール数だけ)
                import connectors
                self.reply(200, json.dumps({'now': time.time(), 'snap': connectors.snapshot()}, ensure_ascii=False), js)
            elif route == '/claude_state.json':  # Claude が保存した、スレッドの状態(題名・状態・次に要ること。会話の本文は含まない)
                import claude_state
                self.reply(200, json.dumps({'now': time.time(), 'snap': claude_state.snapshot()}, ensure_ascii=False), js)
            elif route.startswith('/icon/'):  # 接続の一覧のアイコン(Claude が /connectors のときにダウンロードして保存したもの)
                import connectors
                fname = route[len('/icon/'):]
                f = connectors.ICON_DIR / fname
                if not connectors.ICON_RE.fullmatch(fname) or not f.is_file():  # 決まった形の名前だけ。パスの指定は受け付けない
                    self.send_error(404)
                    return
                self.reply_bytes(200, f.read_bytes(), connectors.ICON_TYPES[fname.rsplit('.', 1)[1]])
            elif route == '/permissions.json':
                import permissions
                self.reply(200, json.dumps(permissions.compute(root), ensure_ascii=False), js)
            elif route == '/pick':
                if self.headers.get('X-FM') != '1':
                    self.send_error(403)
                    return
                try:
                    self.reply(200, json.dumps({'path': pick_folder()}, ensure_ascii=False), js)
                except Exception as e:  # tkinter が無い等。画面側で手入力に切り替える
                    self.reply(200, json.dumps({'error': str(e)}, ensure_ascii=False), js)
            elif route == '/':  # 画面本体。フォルダの調査は画面が /data.json で別に取りにくる(待たずに開ける)
                self.reply(200, app_path.read_text(encoding='utf-8'), html)
            elif route == '/data.json':
                payload, _ = build(root, skip)
                self.reply(200, payload, js)
            else:
                self.send_error(404)

        def log_message(self, *args):
            pass

    try:
        # 自分のPC(127.0.0.1)からだけ接続できる。ネットワークの他の機器には公開しない。
        srv = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    except OSError as e:
        sys.exit('ポート %d を開けません(すでに起動中かもしれません): %s' % (port, e))
    def warm_up():  # 最初の集計は数秒かかるので、画面を開かれる前に済ませておく
        try:
            import token_usage
            token_usage.compute()
            import activity
            activity.compute()
        except Exception:
            pass

    threading.Thread(target=warm_up, daemon=True).start()
    print('常時表示サーバーを起動しました: http://localhost:%d/' % port)
    print('調べているフォルダ:', default)
    print('止めるときは、このウィンドウを閉じるか Ctrl+C を押してください。')
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


def main():
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    here = Path(__file__).resolve().parent
    ap = argparse.ArgumentParser(description='フォルダ構造をツリー図のHTMLにする')
    ap.add_argument('root', nargs='?', default=str(default_root(here)), help='調べるフォルダ(省略時はこのツールを置いた場所)')
    ap.add_argument('--out', help='出力HTMLのパス(省略時は tools/folder-map/output/ 内)')
    ap.add_argument('--no-skip', action='store_true', help='node_modules 等も省略せず全部調べる')
    ap.add_argument('--skip', nargs='*', default=[], help='省略するフォルダ名を追加する')
    ap.add_argument('--no-open', action='store_true', help='出来上がったHTMLをブラウザで開かない')
    ap.add_argument('--serve', action='store_true', help='HTMLを作らず、自動更新する常時表示用サーバーを立てる')
    ap.add_argument('--port', type=int, default=8765, help='--serve のポート番号(既定 8765)')
    a = ap.parse_args()

    root = os.path.abspath(a.root.strip('"'))
    if not os.path.isdir(root):
        sys.exit('フォルダが見つかりません: ' + root)
    skip = set() if a.no_skip else DEFAULT_SKIP | set(a.skip)

    if a.serve:
        serve(root, skip, here, a.port)
        return

    payload, tree = build(root, skip)
    out = Path(a.out) if a.out else here / 'output' / ((os.path.basename(root) or 'root') + '.html')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text((here / 'app.html').read_text(encoding='utf-8').replace(MARK, payload), encoding='utf-8')

    print('フォルダ %d / ファイル %d / %.1f MB' % (count(tree) - 1, tree['fc'], tree['sz'] / 1048576))
    if tree['truncated']:
        print('※ 数が多すぎるため、途中までしか調べていません(%d 件で打ち切り)' % MAX_ENTRIES)
    print('出力:', out, '(%.0f KB)' % (out.stat().st_size / 1024))
    if not a.no_open:
        os.startfile(out) if hasattr(os, 'startfile') else __import__('webbrowser').open(out.as_uri())


if __name__ == '__main__':
    main()

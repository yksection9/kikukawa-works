"""token_usage.py - Claude Code の会話ログ(<設定フォルダ>/projects/**/*.jsonl)から、トークン消費量を集計する。

読み取り専用。ログに書かれた usage(入力・出力・キャッシュ)を、メッセージIDで重複を除いて足し合わせる。
5時間の利用枠は、ログの時刻から「最初の発言の時刻(1時間単位に切り下げ)から5時間」で推定した目安。
プランの上限そのものは分からないので、バーは「過去14日の自分の最大枠」との比で出す。
設定フォルダは、環境変数 CLAUDE_CONFIG_DIR があればそこ、なければ ~/.claude。
"""
import json
import os
import time
from datetime import datetime, timedelta
from pathlib import Path
from threading import Lock

ROOT = Path(os.environ.get('CLAUDE_CONFIG_DIR') or (Path.home() / '.claude')) / 'projects'
WINDOW = 5 * 3600
DAYS = 14
MIN_TURNS = 3  # モデル別の実績は、この件数以上あるものだけ出す

_cache = {}  # ファイルパス -> (更新時刻, サイズ, {メッセージID: 記録}, [依頼ごとの記録])。変わったファイルだけ読み直す
_lock = Lock()


def _ts(s):
    return datetime.fromisoformat(s.replace('Z', '+00:00')).timestamp()


def _is_prompt(o):
    """ユーザー本人の依頼か(ツールの実行結果や自動の注入ではない)。"""
    m = o.get('message')
    if o.get('type') != 'user' or o.get('isMeta') or o.get('isSidechain') or not isinstance(m, dict):
        return False
    c = m.get('content')
    if isinstance(c, list):
        return not any(isinstance(b, dict) and b.get('type') == 'tool_result' for b in c)
    return isinstance(c, str)


def _parse(path):
    recs, turns, cur = {}, [], None
    with open(path, encoding='utf-8', errors='replace') as f:
        for line in f:
            is_a, is_u = '"assistant"' in line, '"user"' in line
            if not ((is_a and '"usage"' in line) or is_u):
                continue
            try:
                o = json.loads(line)
            except ValueError:
                continue
            if _is_prompt(o):
                if cur and cur['calls']:
                    turns.append((cur['ts'], cur['model'], cur['main'], cur['calls']))
                cur = {'ts': 0, 'model': None, 'main': 0, 'calls': 0, 'seen': set()}
                continue
            m = o.get('message')
            if o.get('type') != 'assistant' or not isinstance(m, dict):
                continue
            u, mid, ts = m.get('usage'), m.get('id'), o.get('timestamp')
            model = m.get('model') or '?'
            if not u or not mid or not ts or model.startswith('<'):
                continue
            rec = (_ts(ts), u.get('input_tokens') or 0, u.get('output_tokens') or 0,
                   u.get('cache_creation_input_tokens') or 0, u.get('cache_read_input_tokens') or 0, model)
            old = recs.get(mid)
            if old:  # ストリーミングで同じIDが複数回出る。各項目の大きい方(最終値)を採る
                rec = (old[0],) + tuple(max(a, b) for a, b in zip(old[1:5], rec[1:5])) + (model,)
            recs[mid] = rec
            if cur is not None and not o.get('isSidechain'):  # 依頼ごとの集計は、本人との会話の本流だけ
                if mid not in cur['seen']:
                    cur['seen'].add(mid)
                    cur['calls'] += 1
                    cur['ts'] = cur['ts'] or rec[0]
                    cur['model'] = cur['model'] or model
                cur['main'] = sum(recs[i][1] + recs[i][2] + recs[i][3] for i in cur['seen'])
    if cur and cur['calls']:
        turns.append((cur['ts'], cur['model'], cur['main'], cur['calls']))
    return recs, turns


def _load(now):
    cutoff = now - DAYS * 86400
    allrecs, allturns, seen = {}, [], set()
    with _lock:
        for p in ROOT.rglob('*.jsonl'):
            try:
                st = p.stat()
            except OSError:
                continue
            if st.st_mtime < cutoff:
                continue
            key = str(p)
            seen.add(key)
            c = _cache.get(key)
            if not c or c[0] != st.st_mtime or c[1] != st.st_size:
                try:
                    c = (st.st_mtime, st.st_size) + _parse(p)
                except OSError:
                    continue
                _cache[key] = c
            allrecs.update(c[2])
            allturns.extend(t for t in c[3] if t[0] >= cutoff)
        for k in list(_cache):
            if k not in seen:
                del _cache[k]
    return sorted(r for r in allrecs.values() if r[0] >= cutoff), allturns


def _sum(recs):
    t = {'in': 0, 'out': 0, 'cc': 0, 'cr': 0, 'msgs': len(recs)}
    for r in recs:
        t['in'] += r[1]
        t['out'] += r[2]
        t['cc'] += r[3]
        t['cr'] += r[4]
    t['main'] = t['in'] + t['out'] + t['cc']  # キャッシュ読み込みを除いた「実質の消費」
    return t


def _short(model):
    parts = model.replace('claude-', '').split('-')
    if parts and parts[-1].isdigit() and len(parts[-1]) == 8:
        parts = parts[:-1]
    return '-'.join(parts)


def _q(v, p):
    v = sorted(v)
    return v[min(len(v) - 1, int(len(v) * p))]


TAIL = 2_000_000  # 会話ログは末尾だけ読む(最新の状態さえ分かればよい)
ACTIVE_HOURS = 3  # この時間以内に動いた会話だけ「今の会話」とみなす
MAX_SESSIONS = 4
CTX_SMALL = 200_000  # 会話に入る量の上限は20万と100万があり、ログに印は残らない。20万を超えた記録があれば100万と推定する
CTX_BIG = 1_000_000


def _ctx_max(recs):
    """モデルごとに、過去14日で一度に読み込んだ量の最大値(上限の推定に使う)。"""
    out = {}
    for r in recs:
        k = _short(r[5])
        v = r[1] + r[3] + r[4]
        if v > out.get(k, 0):
            out[k] = v
    return out


def sessions(now, model_max=None):
    """最近動いている会話ごとに、今の会話の長さ(直近のAI呼び出しで読み込んだ量)を返す。"""
    files = []
    for p in ROOT.rglob('*.jsonl'):
        if 'subagents' in p.parts:
            continue
        try:
            mt = p.stat().st_mtime
        except OSError:
            continue
        if mt >= now - ACTIVE_HOURS * 3600:
            files.append((mt, p))
    out = []
    for mt, p in sorted(files, reverse=True)[:MAX_SESSIONS]:
        try:
            size = p.stat().st_size
            with open(p, 'rb') as f:
                if size > TAIL:
                    f.seek(size - TAIL)
                    f.readline()  # 途中から読み始めた最初の行は欠けているので捨てる
                lines = f.read().decode('utf-8', 'replace').splitlines()
        except OSError:
            continue
        title = custom = model = None
        cwds = {}
        last = None
        for line in reversed(lines):
            if '-title"' in line or '"usage"' in line or '"cwd"' in line:
                try:
                    o = json.loads(line)
                except ValueError:
                    continue
                if o.get('cwd'):
                    cwds[o['cwd']] = cwds.get(o['cwd'], 0) + 1
                if o.get('type') == 'ai-title':
                    title = title or o.get('aiTitle')
                elif o.get('type') == 'custom-title':  # デスクトップアプリ等で付く題名(利用者が付けた名前を優先)
                    custom = custom or o.get('customTitle')
                m = o.get('message')
                if o.get('type') == 'assistant' and isinstance(m, dict) and not o.get('isSidechain'):
                    u = m.get('usage')
                    if u and not (m.get('model') or '<').startswith('<'):
                        ctx = (u.get('input_tokens') or 0) + (u.get('cache_creation_input_tokens') or 0) + (u.get('cache_read_input_tokens') or 0)
                        if last is None:
                            last, model = ctx, m.get('model')
        if last is None:
            continue
        cwd = max(cwds, key=cwds.get) if cwds else None  # いちばん多く記録されたフォルダ=会話の本来のフォルダ
        folder = (cwd or '').replace('\\', '/').rstrip('/').split('/')[-1] if cwd else ''
        short = _short(model or '?')
        big = max(last, (model_max or {}).get(short, 0)) > CTX_SMALL
        out.append({'id': p.stem, 'title': custom or title or '(題名なし)', 'folder': folder, 'model': short,
                    'context': last, 'updated': mt,
                    'limit': CTX_BIG if big else CTX_SMALL, 'limit_basis': 'observed' if big else 'assumed'})
    return out


PLAN_FILE = ROOT.parent / 'cc-window-kit' / 'plan_usage.json'


def plan_snapshot(now):
    """アプリの使用量リングと同じ値(Claude が会話の中で取得して保存したもの)。無い・壊れていれば None。
    この窓自身は認証トークンを読まないので、値を取れるのは Claude が保存したときだけ。取得時刻つきで出す。"""
    try:
        o = json.loads(PLAN_FILE.read_text(encoding='utf-8'))
        wins = []
        for w in o['windows']:
            wins.append({'label': str(w['label']), 'pct': float(w['percentUsed']), 'resets': _ts(w['resetsAt'])})
        return {'plan': str(o.get('plan') or ''), 'taken': float(o['taken']), 'windows': wins}
    except (OSError, ValueError, KeyError, TypeError):
        return None


def compute():
    now = time.time()
    recs, turns = _load(now)

    blocks, cur = [], None
    for r in recs:
        t = r[0]
        if cur is None or t >= cur['end'] or t - cur['last'] >= WINDOW:
            start = t - (t % 3600)
            cur = {'start': start, 'end': start + WINDOW, 'last': t, 'recs': []}
            blocks.append(cur)
        cur['recs'].append(r)
        cur['last'] = t

    active = None
    if blocks and now < blocks[-1]['end'] and now - blocks[-1]['last'] < WINDOW:
        active = blocks[-1]
    block = None
    if active:
        by = {}
        for r in active['recs']:
            by[r[5]] = by.get(r[5], 0) + r[1] + r[2] + r[3]
        block = dict(_sum(active['recs']), start=active['start'], end=active['end'],
                     models=sorted(([_short(k), v] for k, v in by.items()), key=lambda x: -x[1]))

    per_model = {}
    for _, model, main, _calls in turns:
        per_model.setdefault(_short(model), []).append(main)
    stats = [{'model': k, 'n': len(v), 'median': _q(v, .5), 'p90': _q(v, .9)}
             for k, v in per_model.items() if len(v) >= MIN_TURNS]
    stats.sort(key=lambda x: -x['n'])

    day0 = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    midnight = day0.timestamp()
    daily = []  # 14日分の日別(古い順)。棒グラフ用
    for i in range(DAYS - 1, -1, -1):
        s, e = (day0 - timedelta(days=i)).timestamp(), (day0 - timedelta(days=i - 1)).timestamp()
        part = [r for r in recs if s <= r[0] < e]
        daily.append({'day': s, 'main': _sum(part)['main'], 'msgs': len(part)})
    return {
        'now': now,
        'no_data': not recs,
        'block': block,
        'last_msg': recs[-1][0] if recs else None,
        'max_block': max([_sum(b['recs'])['main'] for b in blocks], default=0),
        'days': DAYS,
        'today': _sum([r for r in recs if r[0] >= midnight]),
        'week': _sum([r for r in recs if r[0] >= now - 7 * 86400]),
        'per_request': stats,
        'daily': daily,
        'sessions': sessions(now, _ctx_max(recs)),
        'plan': plan_snapshot(now),
    }


if __name__ == '__main__':
    import sys
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    t0 = time.time()
    d = compute()
    print(json.dumps(d, ensure_ascii=False, indent=1))
    print('計算 %.1f 秒' % (time.time() - t0))

"""claude_state.py - Claude のスレッド(プロジェクトの会話)の状態を、保存したファイルから読む。

状態は、Claude が get_session で取得して保存したもの(claude_state.json)。この窓自身は、claude.ai にも認証情報にも触れない。
保存するのは、プロジェクト名・題名・状態・更新時刻・次に要ること・会話の長さ・コストだけ。会話の本文は保存しない。
読む場所は、(1) データベース(スレッド自身が、ターンの終わりに書いた状態。supabase_read.json があるときだけ。読み取り専用)、
(2) このフォルダの2つ上の claude_state/claude_state.json (Claude が取得して保存した値)、(3) 設定フォルダ/cc-window-kit/ の順。
窓の通信は、(1) のデータベースの読み取り(GET)だけ。認証は、利用者自身のデータベースの読み取り専用の鍵で、Claude の認証情報は読まない。
"""
import datetime
import json
import time
import urllib.request

from activity import mask
from token_usage import PLAN_FILE

from pathlib import Path

HERE = Path(__file__).resolve().parent
CANDIDATES = [HERE.parent.parent / 'claude_state' / 'claude_state.json', PLAN_FILE.parent / 'claude_state.json']
CONF = HERE.parent.parent / 'claude_state' / 'supabase_read.json'
BUCKETS = {'working', 'blocked', 'review_ready', 'completed', 'failed', 'unknown'}


def _epoch(s):
    try:
        d = datetime.datetime.fromisoformat(str(s).replace('Z', '+00:00'))
        return d.timestamp() if d.tzinfo else d.replace(tzinfo=datetime.timezone.utc).timestamp()
    except ValueError:
        return None


def _num(v, lo, hi):
    try:
        v = float(v)
        return v if lo <= v <= hi else None
    except (TypeError, ValueError):
        return None


def clean(s):
    """1件分を検査・整形する。想定外の値は安全な値に置き換え、文章は伏せ字にする。"""
    b = str(s.get('bucket', '')).strip()
    return {'project': mask(s.get('project'), 40) or '(名前なし)', 'title': mask(s.get('title'), 60) or '(題名なし)',
            'bucket': b if b in BUCKETS else 'unknown', 'updated': _epoch(s.get('updated_at')),
            'need': mask(s.get('needs_action'), 120), 'error': bool(s.get('error')),
            'ctx': _num(s.get('context_tokens'), 0, 10**7), 'cost': _num(s.get('cost_usd'), 0, 10**5)}


_cache = {'t': 0.0, 'rows': None}


def live_rows():
    """データベースから、スレッドの状態を読む(GET だけ。15秒は同じ結果を返す)。設定がない・つながらないときは None。"""
    if time.time() - _cache['t'] < 15:
        return _cache['rows']
    rows = None
    try:
        c = json.loads(CONF.read_text(encoding='utf-8'))
        if str(c['url']).startswith('https://'):
            req = urllib.request.Request(
                c['url'].rstrip('/') + '/rest/v1/thread_status?select=session_id,project,title,status,needs_action,updated_at&order=updated_at.desc&limit=300',
                headers={'apikey': c['key'], 'x-window-key': c['header_key']})
            with urllib.request.urlopen(req, timeout=4) as r:
                rows = json.loads(r.read().decode('utf-8'))
            if not isinstance(rows, list):
                rows = None
    except (OSError, ValueError, KeyError, TypeError):
        rows = None
    _cache['t'], _cache['rows'] = time.time(), rows
    return rows


def snapshot():
    """スレッドの状態。データベースの行を優先し、足りない分は保存したファイルで補う。どちらも無ければ None。"""
    base = file_snapshot()
    rows = live_rows()
    if rows is None:
        return base
    by = {}
    for s in (base['sessions'] if base else []):
        by[s['id']] = s
    for r in rows:
        if isinstance(r, dict) and r.get('session_id'):
            by[str(r['session_id'])] = dict(clean({**r, 'bucket': r.get('status')}), id=str(r['session_id']))
    order = sorted(by.values(), key=lambda x: -(x.get('updated') or 0))[:300]
    return {'taken': time.time(), 'live': True, 'sessions': order, 'rate': base['rate'] if base else None}


def file_snapshot():
    """保存された状態。無い・壊れていれば None。"""
    for f in CANDIDATES:
        try:
            o = json.loads(f.read_text(encoding='utf-8'))
            taken = _epoch(o['updated_at'])
            if taken is None:
                continue
            rl = o.get('rate_limit') or {}
            return {'taken': taken, 'sessions': [dict(clean(s), id=str(s.get('id'))) for s in o['sessions']][:300],
                    'rate': {'status': mask(rl.get('status'), 20), 'resets': _epoch(rl.get('resets_at'))} if rl else None}
        except (OSError, ValueError, KeyError, TypeError, AttributeError):
            continue
    return None


if __name__ == '__main__':
    import sys
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    print(json.dumps(snapshot(), ensure_ascii=False, indent=1))

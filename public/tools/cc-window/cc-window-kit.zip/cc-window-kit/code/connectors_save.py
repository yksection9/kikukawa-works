"""connectors_save.py - Claude が取得した「連携しているサービスの一覧」を、窓用のファイルに保存する(取得時刻はここで付ける)。

使い方: python connectors_save.py "<名前>|<種類>|<状態>|<ツール数>" ...
  種類: connector / plugin / extension / other   状態: connected / needs_auth / failed / pending / disabled
  ツール数が分からないときは空にする(例: "scheduled-tasks|other|connected|")。名前に | が入っていても、後ろの3つで切り分ける。
値は Claude が会話の中で取得したもの。この窓自身は、設定ファイルも認証情報も読まない。
保存するのは、名前・種類・状態・ツール数だけ。URL・ID・認証情報は渡さない・保存しない(connectors.clean が形を整える)。
前回ダウンロードしたアイコン(icons/ に残っているもの)は、同じ名前のサービスに引き継ぐ。アイコンの取得は connectors_icons.py。
"""
import json
import sys
import time

from connectors import FILE, ICON_DIR, clean, snapshot


def main(argv):
    if len(argv) < 2:
        print('usage: connectors_save.py "<name>|<kind>|<status>|<tools>" ...')
        return 2
    old = {s['name']: s['icon'] for s in ((snapshot() or {}).get('servers') or []) if s.get('icon')}
    servers = []
    for a in argv[1:]:
        parts = a.rsplit('|', 3)
        if len(parts) != 4:
            print('bad item: ' + a[:60])
            return 2
        s = clean(*parts)
        icon = old.get(s['name'])
        s['icon'] = icon if icon and (ICON_DIR / icon).is_file() else None
        servers.append(s)
    FILE.parent.mkdir(parents=True, exist_ok=True)
    FILE.write_text(json.dumps({'taken': time.time(), 'servers': servers}, ensure_ascii=False), encoding='utf-8')
    print('connectors_saved: %d' % len(servers))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))

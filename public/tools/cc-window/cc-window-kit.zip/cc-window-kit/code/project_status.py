"""project_status.py - プロジェクトの状態(進行中・停止中・中止・完了…)の記録を読む。読み取り専用。

調べているフォルダの直下に置いた project_status.json だけを読む(ほかのファイルは読まない・書き込まない)。
書式(UTF-8):
    {"フォルダ名": {"状態": "停止中", "日付": "2026-10-01", "メモ": "一言"}, ...}
状態は 進行中 / 停止中 / 未着手 / 完了 / 中止 / 常設 のどれか。日付は、その状態を記録した日。
フォルダ名は、調べているフォルダの直下にあるフォルダの名前(大文字小文字は区別しない)。
読めないとき・書式が違うときは、止めずに「警告」として画面に出す。
"""
import json
import os
import re
from pathlib import Path

from activity import mask

FILE = 'project_status.json'
MAX_BYTES = 200000
MAX_NOTE = 160
KEYS = {'進行中': 'active', '停止中': 'paused', '未着手': 'idea', '完了': 'done', '中止': 'cancelled', '常設': 'standing'}
# 言い換えも受け付ける(画面には、正式な言葉で出す)
ALIASES = {'保留': '停止中', '中断': '停止中', '一時停止': '停止中', '休止': '停止中', '構想': '未着手', '断念': '中止', '廃止': '中止', '終了': '完了'}
DATE_RE = re.compile(r'\d{4}-\d{2}-\d{2}')


def load(root, folder_names):
    """root 直下の project_status.json を読む。
    返す値: {'found': ファイルがあるか, 'items': {フォルダ名(小文字): {...}}, 'warn': [画面に出す警告]}"""
    out = {'found': False, 'items': {}, 'warn': []}
    f = Path(root) / FILE
    try:
        if f.is_symlink() or not f.is_file():
            return out
        out['found'] = True
        if f.stat().st_size > MAX_BYTES:
            out['warn'].append('%s が大きすぎるため読んでいません(%d KB まで)' % (FILE, MAX_BYTES // 1000))
            return out
        data = json.loads(f.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError) as e:  # 読めない・JSONが壊れている
        out['found'] = True
        out['warn'].append('%s を読めませんでした(%s)' % (FILE, str(e)[:80]))
        return out
    if not isinstance(data, dict):
        out['warn'].append('%s の形が違います(フォルダ名ごとの記録の一覧にしてください)' % FILE)
        return out
    names = {n.lower() for n in folder_names}
    for name, v in data.items():
        if name.startswith('_'):  # "_説明" など、書き手用のメモ欄
            continue
        if not isinstance(v, dict):
            out['warn'].append('「%s」の記録の形が違います' % name)
            continue
        label = str(v.get('状態', '')).strip()
        label = ALIASES.get(label, label)
        if label not in KEYS:
            out['warn'].append('「%s」の状態「%s」を読めません(進行中・停止中・未着手・完了・中止・常設のどれか)' % (name, mask(label, 20)))
            continue
        date = str(v.get('日付', '')).strip()
        if date and not DATE_RE.fullmatch(date):
            out['warn'].append('「%s」の日付「%s」は YYYY-MM-DD の形にしてください' % (name, mask(date, 20)))
            date = ''
        if name.lower() not in names:
            out['warn'].append('「%s」の記録があるのに、その名前のフォルダがありません(名前を変えた/移した?)' % name)
            continue
        out['items'][name.lower()] = {'s': KEYS[label], 'l': label, 'd': date, 'm': mask(v.get('メモ', ''), MAX_NOTE)}
    return out


def attach(tree):
    """build() が作った木の、直下のフォルダに状態を付ける('st')。木には 'ps' (found と warn)も付く。"""
    names = [c['n'] for c in tree['d']]
    r = load(tree['root'], names)
    for c in tree['d']:
        st = r['items'].get(c['n'].lower())
        if st:
            c['st'] = st
    tree['ps'] = {'found': r['found'], 'warn': r['warn']}

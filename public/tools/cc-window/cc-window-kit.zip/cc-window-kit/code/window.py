"""window.py - 見える化ウィンドウ(ホーム・ファイル・使用量・安全・早見表)を、独立したウィンドウで最前面に出す。

使い方: python window.py home | map | usage | commands | safety | all
- 窓は1つ。引数は「どの画面を開くか」(map=ファイルの地図、usage=使用量、all=ホーム)
- サーバー(folder_map.py --serve)が動いていなければ、見えない状態で起動する
- すでに窓があれば、新しく作らず最前面に出し、画面だけ切り替える
- Windows: Edge(なければ Chrome)の「アプリ表示」(アドレスバーなしの専用ウィンドウ)を最前面固定で出す
- Windows 以外: 普通のブラウザのタブで開く(最前面固定はしない)
閉じるときは普通に × で閉じる。
"""
import os
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

PORT = int(os.environ.get('FM_PORT') or 8765)  # 試験用に環境変数 FM_PORT で変えられる。ふだんは 8765
HERE = Path(__file__).resolve().parent
IS_WIN = sys.platform == 'win32'
TITLE = '見える化ウィンドウ'  # ページの <title> と同じにする(窓を探す目印。画面ごとに変えない)
SIZE = (440, 780)
# 引数: 開く画面(app.html の # 以降)
ROUTES = {
    'home': 'home', 'all': 'home', 'map': 'files/map', 'files': 'files', 'usage': 'usage',
    'safety': 'safety', 'connect': 'safety/connect', 'commands': 'commands',
}
BROWSERS = [
    r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
    r'C:\Program Files\Microsoft\Edge\Application\msedge.exe',
    r'C:\Program Files\Google\Chrome\Application\chrome.exe',
    r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
]
HWND_TOPMOST = -1
SWP_NOSIZE, SWP_NOMOVE, SWP_SHOWWINDOW = 0x0001, 0x0002, 0x0040

if IS_WIN:
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    user32.SetProcessDPIAware()
    # 64bit環境でウィンドウ番号(-1 を含む)が正しく渡るよう、引数の型を明示する
    user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                    ctypes.c_int, ctypes.c_int, wintypes.UINT]
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.IsIconic.argtypes = [wintypes.HWND]
    user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]


def server_up():
    try:
        socket.create_connection(('127.0.0.1', PORT), timeout=0.5).close()
        return True
    except OSError:
        return False


def start_server():
    if server_up():
        return
    kw = {'creationflags': 0x08000000 | 0x00000008} if IS_WIN else {'start_new_session': True}  # 窓を出さず切り離して起動
    subprocess.Popen([sys.executable, str(HERE / 'folder_map.py'), '--serve', '--port', str(PORT)],
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)
    for _ in range(40):
        if server_up():
            return
        time.sleep(0.25)
    sys.exit('サーバーを起動できませんでした')


def find_window(title):
    found = []
    proto = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            buf = ctypes.create_unicode_buffer(256)
            user32.GetWindowTextW(hwnd, buf, 256)
            if buf.value.startswith(title):
                found.append(hwnd)
        return True

    user32.EnumWindows(proto(cb), 0)
    return found[0] if found else None


def switch_screen(route):
    """すでに開いている窓の画面を切り替えるよう、サーバーの伝言板に書く(窓が数秒ごとに見て切り替える)。"""
    req = urllib.request.Request('http://127.0.0.1:%d/nav?tab=%s' % (PORT, route), headers={'X-FM': '1'})
    try:
        urllib.request.urlopen(req, timeout=3).close()
    except OSError:
        pass  # 切り替えられなくても、窓は手前に出ている


def open_page(name):
    route = ROUTES[name]
    url = 'http://localhost:%d/#%s' % (PORT, route)
    exe = next((b for b in BROWSERS if os.path.exists(b)), None) if IS_WIN else None
    # 結果は英数字だけで1行出す(呼び出し元が文字コードを取り違えても読めるように)。日本語の案内は呼び出し側が付ける
    if not exe:  # Windows 以外、または Edge/Chrome が無い場合は、普通のブラウザで開く
        webbrowser.open(url)
        print('window: %s opened in browser' % name)
        return

    hwnd = find_window(TITLE)
    if hwnd:
        if user32.IsIconic(hwnd):
            user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        user32.SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
        switch_screen(route)
        print('window: %s raised' % name)
        return
    subprocess.Popen([exe, '--app=' + url])
    for _ in range(60):
        hwnd = find_window(TITLE)
        if hwnd:
            break
        time.sleep(0.25)
    else:
        sys.exit('ウィンドウが見つかりませんでした')
    scale = user32.GetDpiForSystem() / 96  # 表示倍率(150%なら1.5)。画面の大きさに合わせて物理ピクセルにする
    sw, sh = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
    w, h = int(SIZE[0] * scale), min(int(SIZE[1] * scale), sh - int(80 * scale))
    if user32.IsIconic(hwnd):  # 前回、最小化したまま閉じていると、最小化で開くことがある
        user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    user32.SetWindowPos(hwnd, HWND_TOPMOST, sw - w - 24, 24, w, h, SWP_SHOWWINDOW)
    print('window: %s opened' % name)


def main():
    arg = sys.argv[1] if len(sys.argv) > 1 else ''
    if arg not in ROUTES:
        sys.exit('使い方: python window.py home | map | usage | commands | safety | connect | all')
    start_server()
    open_page(arg)


if __name__ == '__main__':
    main()

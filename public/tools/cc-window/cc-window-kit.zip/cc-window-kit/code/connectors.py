"""connectors.py - Claude に連携しているサービス(MCP・コネクタ)の一覧を、保存したスナップショットから読む。

一覧は、Claude が会話の中で取得して保存したもの(connectors_save.py)。この窓自身は、設定ファイルも認証情報も読まない。
保存するのは、サービスの名前・種類・状態・ツール数と、アイコン画像のファイル名だけ。接続先の URL・ID・認証情報は保存しない。
アイコン画像は、Claude が /connectors のときに一度だけダウンロードして、icons/ に保存する(connectors_icons.py)。窓は外部と通信しない。
保存先は token_usage.PLAN_FILE と同じフォルダ(設定フォルダ/cc-window-kit/)。ツール自身の記録で、利用者のファイルではない。
"""
import hashlib
import json
import re

from token_usage import PLAN_FILE

FILE = PLAN_FILE.parent / 'connectors.json'
ICON_DIR = PLAN_FILE.parent / 'icons'
KINDS = {'connector', 'plugin', 'extension', 'other'}
STATUSES = {'connected', 'needs_auth', 'failed', 'pending', 'disabled'}
ICON_RE = re.compile(r'^[0-9a-f]{16}\.(png|jpg|gif|webp|ico)$')  # 保存・配信できるのは、この形のファイル名だけ(パスの指定を許さない)
ICON_TYPES = {'png': 'image/png', 'jpg': 'image/jpeg', 'gif': 'image/gif', 'webp': 'image/webp', 'ico': 'image/x-icon'}
_CTRL = re.compile(r'[\x00-\x1f\x7f]')


def icon_stem(name):
    """サービス名から、アイコンのファイル名(拡張子なし)を決める。同じ名前なら、いつも同じ名前になる。"""
    return hashlib.sha1(str(name).encode('utf-8')).hexdigest()[:16]


def clean(name, kind, status, tools, icon=None):
    """1件分を検査・整形する。想定外の値は安全な値に置き換える(保存・表示の両方で使う)。"""
    name = _CTRL.sub('', str(name)).strip()[:80] or '(名前なし)'
    kind = str(kind).strip()
    status = str(status).strip()
    try:
        tools = int(str(tools).strip())
        tools = tools if 0 <= tools < 100000 else None
    except ValueError:
        tools = None
    icon = icon if isinstance(icon, str) and ICON_RE.fullmatch(icon) else None
    return {'name': name, 'kind': kind if kind in KINDS else 'other',
            'status': status if status in STATUSES else 'unknown', 'tools': tools, 'icon': icon}


def snapshot():
    """保存された一覧。無い・壊れていれば None。"""
    try:
        o = json.loads(FILE.read_text(encoding='utf-8'))
        servers = [clean(s['name'], s['kind'], s['status'], s.get('tools'), s.get('icon')) for s in o['servers']][:200]
        return {'taken': float(o['taken']), 'servers': servers}
    except (OSError, ValueError, KeyError, TypeError):
        return None


if __name__ == '__main__':
    import sys
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    print(json.dumps(snapshot(), ensure_ascii=False, indent=1))

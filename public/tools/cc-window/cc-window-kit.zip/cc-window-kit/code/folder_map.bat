@echo off
rem Double-click: map the whole work folder. Drag a folder onto this file: map that folder.
chcp 65001 >nul
python "%~dp0folder_map.py" %*
pause

@echo off
rem ASCII only on purpose: cmd breaks on Japanese text in .bat files. Messages live in the .txt files.
chcp 65001 >nul
where python >nul 2>nul
if errorlevel 1 goto nopython
python "%~dp0window.py" all
if errorlevel 1 goto failed
exit /b 0

:nopython
echo.
type "%~dp0message_python.txt"
echo.
pause
exit /b 1

:failed
echo.
type "%~dp0message_failed.txt"
echo.
pause
exit /b 1

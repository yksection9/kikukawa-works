"""permissions.py - Claude Code の許可ルール(settings.json の permissions)を読み取り、日本語の一覧にする。

読み取り専用。settings.json のうち読むのは `permissions` の中だけ(env・hooks・認証情報などは取り出さない)。
画面に出す文は activity.mask で秘密らしい文字列を伏せる。
ここに出ないもの: アプリの画面で選んだ権限モード(会話ごと・ファイルに残らない)、会話中の「今回だけ許可」、組織の管理設定の中身。
"""
import json
import os
import re
import sys
from pathlib import Path

from activity import mask

CONFIG = Path(os.environ.get('CLAUDE_CONFIG_DIR') or (Path.home() / '.claude'))
MAX_BYTES = 1_000_000
MAX_RULES = 300
SHOW = 200  # 1ルールの表示文字数の上限

MODES = {
    'default': '標準(ファイルの編集やコマンドの実行は確認が出る)',
    'acceptEdits': 'ファイルの編集は確認なし(コマンドは確認が出る)',
    'plan': '計画だけ作る(実行はしない)',
    'bypassPermissions': 'すべて確認なし(影響が大きい設定)',
}
EDIT_TOOLS = {'Edit', 'Write', 'MultiEdit', 'NotebookEdit'}
CMD_TOOLS = {'Bash': 'Bash', 'PowerShell': 'PowerShell'}
RX = re.compile(r'^([A-Za-z_][\w.:-]*)(?:\((.*)\))?$', re.S)


def _managed_exists():
    for p in (r'C:\ProgramData\ClaudeCode\managed-settings.json', '/etc/claude-code/managed-settings.json',
              '/Library/Application Support/ClaudeCode/managed-settings.json'):
        try:
            if Path(p).is_file():
                return True
        except OSError:
            pass
    return False


def explain(rule):
    """ルール1つを日本語にする。返り値: (説明, 範囲が広いか)。"""
    m = RX.match(rule.strip())
    if not m:
        return rule, False
    tool, pat = m.group(1), m.group(2)
    pat = (pat or '').strip()
    if tool in CMD_TOOLS:
        if pat in ('', '*', ':*'):
            return 'あらゆるコマンド(%s)' % tool, True
        if pat.endswith(':*'):
            pre = pat[:-2]
        elif pat.endswith('*') and '*' not in pat[:-1]:
            pre = pat[:-1].rstrip()
        else:
            pre = None
        if pre is not None:
            return '「%s」で始まるコマンド(%s)' % (pre, tool), False
        if '*' in pat:
            return '「%s」に合うコマンド(%s)' % (pat, tool), False
        return 'コマンド「%s」だけ(%s)' % (pat, tool), False
    if tool in EDIT_TOOLS:
        return ('「%s」を書き換える・作る' % pat, False) if pat and pat != '*' else ('あらゆるファイルを書き換える・作る', True)
    if tool == 'Read':
        return ('「%s」を読む' % pat, False) if pat and pat != '*' else ('あらゆるファイルを読む', False)
    if tool in ('Glob', 'Grep'):
        return ('「%s」の中を探す' % pat, False) if pat else ('ファイルの中を探す', False)
    if tool == 'WebFetch':
        if pat.startswith('domain:'):
            return 'Webページ(%s)を読む' % pat[7:], False
        return ('Webページ「%s」を読む' % pat, False) if pat else ('あらゆるWebページを読む', True)
    if tool == 'WebSearch':
        return 'Webで検索する', False
    if tool.startswith('mcp__'):
        parts = tool.split('__')
        server = parts[1] if len(parts) > 1 else '?'
        name = parts[2] if len(parts) > 2 else ''
        if not name or name == '*':
            return '外部ツール(MCP)「%s」のすべての機能' % server, True
        return '外部ツール(MCP)「%s」の「%s」' % (server, name), False
    if tool in ('Agent', 'Task'):
        return ('助手(サブエージェント)「%s」' % pat) if pat else '助手(サブエージェント)', False
    if tool == 'Skill':
        return ('スキル「%s」' % pat) if pat else 'スキル', False
    return rule, False


def _rules(perm, kind):
    v = perm.get(kind)
    out = []
    for r in (v if isinstance(v, list) else [])[:MAX_RULES]:
        if not isinstance(r, str):
            continue
        raw = mask(r, SHOW)
        jp, broad = explain(raw)
        out.append({'raw': raw, 'jp': jp, 'broad': broad})
    return out


def _read(path, scope, label):
    e = {'scope': scope, 'label': label, 'path': mask(str(path), 240), 'exists': False}
    try:
        if not path.is_file():
            return e
        e['exists'] = True
        if path.stat().st_size > MAX_BYTES:
            e['error'] = '大きすぎて読んでいません'
            return e
        o = json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError):
        e['error'] = '読めませんでした(形式が壊れているかもしれません)'
        return e
    perm = o.get('permissions') if isinstance(o, dict) else None  # permissions 以外のキーは見ない
    if not isinstance(perm, dict):
        perm = {}
    mode = perm.get('defaultMode')
    e['mode'] = mode if isinstance(mode, str) else None
    e['mode_text'] = MODES.get(mode, '(設定値: %s)' % mask(mode, 40)) if isinstance(mode, str) else None
    for k in ('allow', 'ask', 'deny'):
        e[k] = _rules(perm, k)
    d = perm.get('additionalDirectories')
    e['dirs'] = [mask(x, SHOW) for x in d[:20] if isinstance(x, str)] if isinstance(d, list) else []
    return e


def compute(root):
    root = Path(root).resolve() if root else None
    files = [_read(CONFIG / 'settings.json', 'all', 'あなたのPC全体'),
             _read(CONFIG / 'settings.local.json', 'all', 'あなたのPC全体(自分用・共有されない)')]
    seen = {str((CONFIG).resolve())}
    if root:
        d = root
        for i in range(5):  # このフォルダと、上のフォルダ(4つまで)
            c = d / '.claude'
            if str(c.resolve()) not in seen:
                seen.add(str(c.resolve()))
                nm = 'このフォルダ' if i == 0 else '上のフォルダ「%s」' % (d.name or str(d))
                files.append(_read(c / 'settings.json', 'folder', nm + '(共有される設定)'))
                files.append(_read(c / 'settings.local.json', 'folder', nm + '(自分用・共有されない)'))
            if d.parent == d:
                break
            d = d.parent
    found = [f for f in files if f['exists']]
    env_rules = [r['raw'] for f in found for r in f.get('deny', []) if r['raw'].startswith('Read') and re.search(r'\.env', r['raw'])]
    return {
        'found': found,
        'missing': [f['path'] for f in files if not f['exists']],
        'env_read_denied': bool(env_rules),
        'env_rules': env_rules[:5],
        'managed': _managed_exists(),
    }


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    print(json.dumps(compute(sys.argv[1] if len(sys.argv) > 1 else os.getcwd()), ensure_ascii=False, indent=1))

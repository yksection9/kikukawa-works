"""activity.py - いまClaudeが何をしているかを、このPCのファイルとプロセスから読み取る。

読み取り専用。次の4つを足し合わせる(AIは使わないので、トークンも消費しない)。
  1. <設定フォルダ>/sessions/<PID>.json   動いているClaude本体と、作業中(busy)/待機(idle)。公式に書かれていない形式なので、
                                          読めないときは会話記録の更新時刻からの推定に切り替える。同じ場所の .key は読まない
  2. 会話の記録(projects/**/<ID>.jsonl)の末尾   結果がまだ付いていない道具の呼び出し=いま実行中の作業。助手(サブエージェント)の記録も見る
  3. プロセスの親子関係                    Claudeが起動して、まだ動いているコマンド(バックテストなど)
  4. GitHub Actions(利用者がリポジトリ名を入れたときだけ)  GitHub CLI(gh)の読み取りの一覧
設定フォルダは、環境変数 CLAUDE_CONFIG_DIR があればそこ、なければ ~/.claude。
単独で実行すると、いまの状態を文字で出す: python activity.py
"""
import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from threading import Lock

from token_usage import ROOT as PROJECTS

SESSIONS = PROJECTS.parent / 'sessions'
IS_WIN = sys.platform == 'win32'
NO_WINDOW = 0x08000000 if IS_WIN else 0  # PowerShell を呼ぶときに黒い画面を出さない

TAIL = 200_000        # 会話記録は末尾だけ読む。巨大な1行で読めないときは、この倍まで広げる
TAIL_MAX = 6_400_000
SUB_ACTIVE = 60       # 助手の記録がこの秒数以内に更新されていれば「作業中」
LONG_CMD = 120        # この秒数を超えて動いているコマンドには「長時間」の印(事実の表示で、助言ではない)
MIN_PROC_AGE = 5      # 起動からこの秒数未満のコマンドは、一瞬で終わるものが多いので出さない
CACHE_SEC = 3         # 全体の再計算は、この秒数以内なら前回の結果を返す(画面を複数開いても負荷を増やさない)
GH_CACHE_SEC = 20
MAX_REPOS = 3

# 道具名 -> (種類, 初心者向けの言い方)
TOOLS = {
    'Bash': ('cmd', 'コマンドを実行している'), 'PowerShell': ('cmd', 'コマンドを実行している'),
    'Monitor': ('cmd', 'コマンドの出力を見張っている'),
    'Edit': ('edit', 'ファイルを書き換えている'), 'MultiEdit': ('edit', 'ファイルを書き換えている'),
    'Write': ('edit', 'ファイルを作っている'), 'NotebookEdit': ('edit', 'ノートブックを書き換えている'),
    'Read': ('read', 'ファイルを読んでいる'), 'Grep': ('search', 'ファイルの中を探している'), 'Glob': ('search', 'ファイルを探している'),
    'WebSearch': ('web', 'Webで検索している'), 'WebFetch': ('web', 'Webページを読んでいる'),
    'Agent': ('agent', '助手(サブエージェント)に任せている'), 'Task': ('agent', '助手(サブエージェント)に任せている'),
    'AskUserQuestion': ('ask', 'あなたの返事を待っている'), 'ExitPlanMode': ('ask', '計画の承認を待っている'),
    'Skill': ('other', 'スキル(定型の手順)を使っている'), 'ToolSearch': ('other', '使う道具を探している'),
    'TodoWrite': ('other', '作業メモを更新している'),
}
SHELLS = {'bash.exe', 'sh.exe', 'cmd.exe', 'powershell.exe', 'pwsh.exe', 'conhost.exe', 'wsl.exe', 'wslhost.exe',
          'bash', 'sh', 'zsh', 'fish', 'dash'}

_lock = Lock()
_base_cache = {'t': 0, 'v': None}
_logs = {}   # 会話記録のパス -> (更新時刻, サイズ, 解析結果)。変わったときだけ読み直す
_gh = {}     # リポジトリ名 -> (取得時刻, 結果)


def _epoch(s):
    try:
        return datetime.fromisoformat(s.replace('Z', '+00:00')).timestamp()
    except (AttributeError, ValueError):
        return None


# ---- 秘密らしい文字列を伏せる(コマンド文を画面に出すため) ----
MASKS = [
    (re.compile(r'sk-[A-Za-z0-9_-]{16,}'), 'sk-***'),
    (re.compile(r'gh[pousr]_[A-Za-z0-9]{20,}'), 'gh*_***'),
    (re.compile(r'xox[baprs]-[A-Za-z0-9-]{10,}'), 'xox*-***'),
    (re.compile(r'AKIA[0-9A-Z]{16}'), 'AKIA***'),
    (re.compile(r'(?i)\bbearer\s+\S+'), 'Bearer ***'),
    (re.compile(r'(?i)(--?(?:token|password|passwd|secret|api[-_]?key)[=\s]+)\S+'), r'\1***'),
    (re.compile(r'(?i)((?:token|password|passwd|secret|api[-_]?key|authorization)\s*[=:]\s*)\S+'), r'\1***'),
    (re.compile(r'(?=[A-Za-z0-9+/_=-]*\d)(?=[A-Za-z0-9+/_=-]*[A-Za-z])[A-Za-z0-9+/_=-]{40,}'), '***'),
]


def mask(s, limit):
    s = re.sub(r'\s+', ' ', str(s or '')).strip()
    for rx, rep in MASKS:
        s = rx.sub(rep, s)
    return s if len(s) <= limit else s[:limit - 1] + '…'


# ---- プロセス ----
PS_CODE = (
    "$ErrorActionPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.Encoding]::UTF8;"
    "Get-CimInstance Win32_Process|ForEach-Object{[pscustomobject]@{p=$_.ProcessId;pp=$_.ParentProcessId;n=$_.Name;"
    "s=$(if($_.CreationDate){[int64]([DateTimeOffset]$_.CreationDate).ToUnixTimeSeconds()}else{0});c=$_.CommandLine}}|ConvertTo-Json -Compress"
)


def _procs():
    """{pid: {ppid, name, start, cmd}} を返す。取れないときは (None, 理由)。"""
    try:
        if IS_WIN:
            r = subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-Command', PS_CODE],
                               capture_output=True, timeout=20, creationflags=NO_WINDOW)
            rows = json.loads(r.stdout.decode('utf-8-sig', 'replace') or '[]')
            if isinstance(rows, dict):
                rows = [rows]
            return {x['p']: {'ppid': x['pp'], 'name': x['n'] or '', 'start': x['s'], 'cmd': x['c'] or ''} for x in rows}, None
        r = subprocess.run(['ps', '-eo', 'pid=,ppid=,etime=,comm=,args='], capture_output=True, timeout=20)
        now, out = time.time(), {}
        for line in r.stdout.decode('utf-8', 'replace').splitlines():
            f = line.split(None, 4)
            if len(f) >= 4 and f[0].isdigit():
                out[int(f[0])] = {'ppid': int(f[1]), 'name': f[3], 'start': now - _etime(f[2]), 'cmd': f[4] if len(f) > 4 else f[3]}
        return out, None
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as e:
        return None, 'プロセスの一覧を取得できませんでした(%s)' % type(e).__name__


def _etime(t):
    """ps の経過時間 [[日-]時:]分:秒 を秒にする。"""
    days, _, rest = t.rpartition('-')
    parts = [int(x) for x in rest.split(':')]
    sec = 0
    for x in parts:
        sec = sec * 60 + x
    return sec + (int(days) * 86400 if days else 0)


def _filetime(ticks):
    """Windows の FILETIME(1601年からの100ナノ秒)を、UNIX秒にする。"""
    try:
        return int(ticks) / 1e7 - 11644473600
    except (TypeError, ValueError):
        return None


def _alive(reg, procs):
    """記録のClaudeが本当に動いているか。True/False、一覧が無ければ None(不明)。"""
    if procs is None or reg.get('pid') is None:  # 一覧が無い、または推定で作った記録(PIDなし)は、判定できない
        return None
    p = procs.get(reg.get('pid'))
    if not p:
        return False
    st = _filetime(reg.get('procStart')) if str(reg.get('pidDomain', '')).startswith('win32') else None
    if st is not None and p['start'] and abs(p['start'] - st) > 5:
        return False  # 同じ番号を別のプロセスが使っている(古い記録)
    return True


def _descendants(pid, kids):
    out, todo = [], list(kids.get(pid, []))
    while todo:
        c = todo.pop()
        out.append(c)
        todo.extend(kids.get(c, []))
    return out


def _short_exe(cmd):
    """コマンド行の先頭の実行ファイルを、フォルダ部分を省いた名前にする(長い行を読みやすくする)。"""
    m = re.match(r'\s*("([^"]+)"|(\S+))(.*)', cmd, re.S)
    if not m:
        return cmd
    exe = m.group(2) or m.group(3)
    return re.split(r'[\\/]', exe)[-1] + m.group(4)


def _commands(pid, procs, kids, now, skip):
    """Claudeの下で動いているコマンド(シェル自身は除く)。"""
    out = []
    for c in _descendants(pid, kids):
        p = procs[c]
        name, age = p['name'], now - p['start'] if p['start'] else 0
        if name.lower() in SHELLS or c in skip or age < MIN_PROC_AGE or 'folder_map.py' in p['cmd']:
            continue
        auto = name.lower().startswith('claude') and re.search(r'\s(-p|--print)(\s|$)', p['cmd']) is not None
        out.append({'pid': c, 'name': name, 'cmd': mask(_short_exe(p['cmd']), 160), 'age': age, 'long': age >= LONG_CMD,
                    'auto': bool(auto)})
    out.sort(key=lambda x: -x['age'])
    return out[:8]


# ---- 会話の記録 ----
def _log_path(sid):
    for p in PROJECTS.glob('*/%s.jsonl' % sid):
        return p
    return None


def _read_tail(path, size, tail):
    with open(path, 'rb') as f:
        if size > tail:
            f.seek(size - tail)
            f.readline()  # 途中から読み始めた最初の行は欠けているので捨てる
        return f.read().decode('utf-8', 'replace').splitlines()


def _parse_log(path):
    """末尾から、結果待ちの道具・作業メモ・最後の記録時刻を読み取る。"""
    size, tail = path.stat().st_size, TAIL
    while True:
        try:
            lines = _read_tail(path, size, tail)
        except OSError:
            return {}
        recs = []
        for line in lines:
            try:
                recs.append(json.loads(line))
            except ValueError:
                continue
        if recs or tail >= min(size, TAIL_MAX):
            break
        tail *= 8  # 巨大な1行しか読めなかったときは、読む範囲を広げる
    pending, todos, last = {}, None, None
    for o in recs:
        if o.get('isSidechain'):
            continue
        last = _epoch(o.get('timestamp')) or last
        c = (o.get('message') or {}).get('content')
        if not isinstance(c, list):
            continue
        for x in c:
            if not isinstance(x, dict):
                continue
            if o.get('type') == 'assistant' and x.get('type') == 'tool_use':
                inp = x.get('input') or {}
                pending[x.get('id')] = {'name': x.get('name') or '', 'input': inp, 'ts': _epoch(o.get('timestamp'))}
                if x.get('name') == 'TodoWrite' and isinstance(inp.get('todos'), list):
                    todos = inp['todos']
            elif o.get('type') == 'user' and x.get('type') == 'tool_result':
                pending.pop(x.get('tool_use_id'), None)
    return {'pending': list(pending.values()), 'todos': todos, 'last': last}


def _log_info(sid):
    p = _log_path(sid)
    if not p:
        return {}, None
    try:
        st = p.stat()
    except OSError:
        return {}, p
    hit = _logs.get(p)
    if hit and hit[0] == st.st_mtime_ns and hit[1] == st.st_size:
        return hit[2], p
    info = _parse_log(p)
    _logs[p] = (st.st_mtime_ns, st.st_size, info)
    return info, p


def _describe(t, now):
    """結果待ちの道具1つを、画面に出す形にする。"""
    name, inp = t['name'], t['input']
    kind, label = TOOLS.get(name, ('other', None))
    if label is None:
        label = '外部の道具「%s」を使っている' % name.split('__')[1] if name.startswith('mcp__') and name.count('__') >= 2 else '%s を使っている' % name
    d = {'kind': kind, 'label': label, 'age': now - t['ts'] if t['ts'] else None, 'bg': bool(inp.get('run_in_background'))}
    if kind == 'cmd':
        d['detail'] = mask(inp.get('description'), 90)
        d['cmd'] = mask(inp.get('command'), 160)
    elif kind in ('edit', 'read'):
        fp = inp.get('file_path') or inp.get('notebook_path') or ''
        d['detail'] = os.path.basename(fp.replace('\\', '/'))
        if kind == 'edit':
            d['path'] = fp
    elif kind == 'search':
        d['detail'] = mask(inp.get('pattern'), 60)
    elif kind == 'web':
        d['detail'] = mask(inp.get('query') or inp.get('url'), 90)
    elif kind == 'agent':
        d['detail'] = mask(inp.get('description'), 80)
    elif kind == 'ask':
        qs = inp.get('questions')
        d['detail'] = mask(qs[0].get('question') if isinstance(qs, list) and qs and isinstance(qs[0], dict) else '', 80)
    return d


def _todo(todos):
    if not todos:
        return None
    rows = [x for x in todos if isinstance(x, dict)]
    done = sum(1 for x in rows if x.get('status') == 'completed')
    cur = next((x for x in rows if x.get('status') == 'in_progress'), None)
    return {'done': done, 'total': len(rows), 'now': mask((cur or {}).get('activeForm') or (cur or {}).get('content'), 70) if cur else ''}


def _subagents(path, now):
    """助手(サブエージェント)の記録のうち、最近更新されているもの=作業中。"""
    out = []
    d = path.parent / path.stem / 'subagents' if path else None
    if not d or not d.is_dir():
        return out
    for f in d.glob('agent-*.jsonl'):
        try:
            age = now - f.stat().st_mtime
        except OSError:
            continue
        if age > SUB_ACTIVE:
            continue
        meta = {}
        try:
            meta = json.loads(f.with_suffix('.meta.json').read_text(encoding='utf-8'))
        except (OSError, ValueError):
            pass
        out.append({'type': meta.get('agentType') or '助手', 'desc': mask(meta.get('description'), 80), 'age': age})
    out.sort(key=lambda x: x['age'])
    return out[:8]


# ---- 動いているClaudeの一覧 ----
def _registry():
    """動いているClaudeの記録を読む。(一覧, 理由) 。フォルダが無い/読めないときは (None, 理由)。"""
    if not SESSIONS.is_dir():
        return None, 'Claudeの状態ファイル(sessions)が見つかりません。会話の記録の更新時刻から推定します'
    out = []
    for f in SESSIONS.glob('*.json'):
        try:
            d = json.loads(f.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            continue
        if isinstance(d, dict) and d.get('pid') and d.get('sessionId'):
            out.append(d)
    return out, None


def _fallback(now):
    """状態ファイルが無いときの推定: 直近3分以内に記録が更新された会話を「動いている」とみなす。"""
    out = []
    for p in PROJECTS.glob('*/*.jsonl'):
        try:
            mt = p.stat().st_mtime
        except OSError:
            continue
        if now - mt <= 180:
            cwd = ''
            for line in _read_tail(p, p.stat().st_size, TAIL)[::-1]:
                if '"cwd"' in line:
                    try:
                        cwd = json.loads(line).get('cwd') or ''
                        break
                    except ValueError:
                        continue
            out.append({'sessionId': p.stem, 'pid': None, 'name': p.stem[:8], 'cwd': cwd, 'status': 'unknown',
                        'statusUpdatedAt': mt * 1000, 'startedAt': mt * 1000, 'kind': None})
    return out


def _base(now):
    procs, perr = _procs()
    reg, rerr = _registry()
    notes = [x for x in (perr, rerr) if x]
    if reg is None:
        reg = _fallback(now)
    kids = {}
    for pid, p in (procs or {}).items():
        kids.setdefault(p['ppid'], []).append(pid)
    skip = {os.getpid()}
    sessions = []
    for r in reg:
        alive = _alive(r, procs)
        if alive is False:
            continue
        info, path = _log_info(r['sessionId'])
        status = r.get('status') or 'unknown'
        s = {'id': r['sessionId'], 'pid': r.get('pid'), 'name': r.get('name') or '(名前なし)', 'cwd': r.get('cwd') or '',
             'status': status, 'status_age': now - (r.get('statusUpdatedAt') or 0) / 1000,
             'started_age': now - (r.get('startedAt') or 0) / 1000, 'kind': r.get('kind'),
             'last_age': now - info['last'] if info.get('last') else None,
             'tools': [], 'todo': _todo(info.get('todos')), 'subagents': _subagents(path, now), 'cmds': [], 'auto': False}
        if status != 'idle':  # 待機中の会話は、結果待ちの道具が残っていても「いま」ではない
            pend = sorted(info.get('pending') or [], key=lambda t: t['ts'] or 0)
            s['tools'] = [_describe(t, now) for t in pend][:4]
        if procs is not None and r.get('pid') in procs:
            s['cmds'] = _commands(r['pid'], procs, kids, now, skip)
            s['auto'] = bool(re.search(r'\s(-p|--print)(\s|$)', procs[r['pid']]['cmd']))
        sessions.append(s)
    sessions.sort(key=lambda s: (s['status'] != 'busy', s['name']))
    busy = sum(1 for s in sessions if s['status'] == 'busy')
    return {'sessions': sessions, 'notes': notes, 'registry': rerr is None,
            'summary': {'claude': len(sessions), 'busy': busy, 'idle': len(sessions) - busy,
                        'cmds': sum(len([c for c in s['cmds'] if not c['auto']]) for s in sessions),
                        'subs': sum(len(s['subagents']) for s in sessions)}}


# ---- GitHub Actions(クラウドで動いているジョブ) ----
REPO_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9-]{0,38}/(?!\.{1,2}$)[A-Za-z0-9._-]{1,100}$')  # GitHub の owner/repo の形だけ受け付ける


def _gh_run(args):
    r = subprocess.run(['gh'] + args, capture_output=True, timeout=25, creationflags=NO_WINDOW)
    return r.returncode, r.stdout.decode('utf-8', 'replace'), r.stderr.decode('utf-8', 'replace')


def _github(repo, now):
    hit = _gh.get(repo)
    if hit and now - hit[0] < GH_CACHE_SEC:
        return hit[1]
    res = {'repo': repo, 'runs': [], 'error': None}
    try:
        if not shutil.which('gh'):
            res['error'] = 'GitHub CLI(gh)が見つかりません。入れてログインすると、ここにGitHub Actionsの実行が出ます'
        else:
            code, out, err = _gh_run(['run', 'list', '--repo', repo, '--limit', '6', '--json',
                                      'databaseId,name,status,conclusion,createdAt'])
            if code != 0:
                low = err.lower()
                res['error'] = ('GitHub にログインしていません(gh auth login)' if 'auth' in low or 'login' in low
                                else 'リポジトリが見つかりません(名前と権限を確認してください)' if '404' in low or 'could not resolve' in low
                                else '取得できませんでした')
            else:
                for x in json.loads(out or '[]'):
                    run = {'id': x['databaseId'], 'name': x['name'], 'status': x['status'], 'conclusion': x.get('conclusion'),
                           'age': now - (_epoch(x['createdAt']) or now), 'jobs': None}
                    if x['status'] != 'completed' and len([r for r in res['runs'] if r['jobs']]) < 3:
                        c2, o2, _ = _gh_run(['run', 'view', str(x['databaseId']), '--repo', repo, '--json', 'jobs'])
                        if c2 == 0:
                            js = json.loads(o2 or '{}').get('jobs') or []
                            run['jobs'] = {'total': len(js), 'running': sum(1 for j in js if j.get('status') == 'in_progress'),
                                           'waiting': sum(1 for j in js if j.get('status') in ('queued', 'waiting', 'pending')),
                                           'done': sum(1 for j in js if j.get('status') == 'completed')}
                    res['runs'].append(run)
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as e:
        res['error'] = '取得できませんでした(%s)' % type(e).__name__
    _gh[repo] = (now, res)
    return res


def compute(gh_repos=()):
    now = time.time()
    with _lock:
        if _base_cache['v'] is None or now - _base_cache['t'] > CACHE_SEC:
            _base_cache.update(t=now, v=_base(now))
        out = dict(_base_cache['v'])
    out['now'] = now
    out['github'] = [_github(r, now) for r in [r for r in gh_repos if REPO_RE.match(r)][:MAX_REPOS]]
    return out


def _fmt(sec):
    if sec is None:
        return '?'
    m = int(sec // 60)
    return '%d秒' % sec if m < 1 else '%d分' % m if m < 60 else '%d時間%d分' % (m // 60, m % 60)


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    d = compute(sys.argv[1:])
    s = d['summary']
    print('動いているClaude %d(作業中 %d・待機 %d)/ 実行中のコマンド %d / 助手 %d' % (s['claude'], s['busy'], s['idle'], s['cmds'], s['subs']))
    for n in d['notes']:
        print('※', n)
    for x in d['sessions']:
        print('-', {'busy': '作業中', 'idle': '待機中'}.get(x['status'], x['status']), x['name'], '|', x['cwd'])
        for t in x['tools']:
            print('    いま:', t['label'], t.get('detail') or '', '(%s)' % _fmt(t['age']))
        for c in x['cmds']:
            print('    コマンド:', c['name'], c['cmd'][:80], '(%s)' % _fmt(c['age']), '長時間' if c['long'] else '')
        for a in x['subagents']:
            print('    助手:', a['type'], a['desc'])
    for g in d['github']:
        print('GitHub', g['repo'], g['error'] or [(r['name'], r['status'], r['jobs']) for r in g['runs']])

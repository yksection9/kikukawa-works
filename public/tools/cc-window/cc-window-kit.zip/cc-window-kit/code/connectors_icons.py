"""connectors_icons.py - 接続の一覧に出す、サービスのアイコン画像をダウンロードして、自分のPCに保存する。

使い方: python connectors_icons.py "<サービス名>|<アイコンのURL>" ...
  アイコンのURLは、Claude の接続の一覧(list_connectors)が返す iconUrl。サービス名は、connectors_save.py で保存した名前と同じものにする。
  iconUrl が画像のURLでなく、サイトのURLだけのとき(Vercel など。MCP サーバーのURLを含む)は、そのサイトには直接アクセスせず、ドメインの favicon を
  Google の favicon 取得サービスから取る(Claude のアプリが Google 系のアイコンに使っているのと同じ取得先)。
/connectors を打ったときだけ動く。窓(見える化ウィンドウ)自身は、外部と通信しない。保存先: 設定フォルダ/cc-window-kit/icons/

安全のための制限(ダウンロード先を、ユーザーの意図しない場所にさせない):
  - https だけ。リダイレクト先も https だけ。localhost・社内/家庭内のアドレス(プライベートIP)・IPアドレスの直指定は拒否する
  - 1枚あたり 256KB まで・全体で8秒まで(1回の通信の待ちも8秒まで)・最大 30枚。画像の中身(先頭のバイト列)が PNG/JPEG/GIF/WebP/ICO のものだけ保存する(SVG は保存しない)
  - ファイル名は、サービス名から作った 16文字の名前だけ(パスを指定できない)。失敗した1枚は、飛ばして続ける
"""
import ipaddress
import json
import socket
import sys
import time
import urllib.error
import urllib.request
from urllib.parse import quote, urlparse

from connectors import FILE, ICON_DIR, clean, icon_stem, snapshot

LIMIT = 256 * 1024
TIMEOUT = 8   # 1回の通信の待ち時間
DEADLINE = 8  # 1枚あたりの、ダウンロード全体の制限時間(ゆっくり送られ続けても、ここで打ち切る)
MAX_ICONS = 30
FAVICON = 'https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=%s&size=64'
SIGNS = [(b'\x89PNG\r\n\x1a\n', 'png'), (b'\xff\xd8\xff', 'jpg'), (b'GIF87a', 'gif'), (b'GIF89a', 'gif'), (b'\x00\x00\x01\x00', 'ico')]


def sniff(data):
    """先頭のバイト列から、画像の種類を決める(サーバーが言う種類は信用しない)。画像でなければ None。"""
    for sign, ext in SIGNS:
        if data.startswith(sign):
            return ext
    if data[:4] == b'RIFF' and data[8:12] == b'WEBP':
        return 'webp'
    return None


def check_public(host):
    """ホストが、インターネット上の公開アドレスだけを指しているかを確かめる。IP直指定・localhost・プライベートIPは拒否。"""
    if not host or host.lower() == 'localhost':
        raise ValueError('host not allowed')
    try:
        ipaddress.ip_address(host.strip('[]'))
        raise ValueError('ip literal not allowed')
    except ValueError as e:
        if 'not allowed' in str(e):
            raise
    for info in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM):
        if not ipaddress.ip_address(info[4][0]).is_global:
            raise ValueError('non-public address')


def check_url(url):
    u = urlparse(url)
    if u.scheme != 'https':
        raise ValueError('https only')
    check_public(u.hostname)


class _Redirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        check_url(newurl)  # リダイレクト先も、同じ検査を通す
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch(url):
    check_url(url)
    opener = urllib.request.build_opener(_Redirect)
    req = urllib.request.Request(url, headers={'User-Agent': 'cc-window-kit/1.0', 'Accept': 'image/*'})
    end = time.monotonic() + DEADLINE
    chunks, size = [], 0
    with opener.open(req, timeout=TIMEOUT) as r:
        while True:
            c = r.read(8192)
            if not c:
                break
            chunks.append(c)
            size += len(c)
            if size > LIMIT:
                raise ValueError('too large')
            if time.monotonic() > end:
                raise ValueError('too slow')
    return b''.join(chunks)


def site_domain(url):
    """サイトのURLから、favicon を探すためのドメインを取り出す(mcp.vercel.com → vercel.com)。"""
    host = (urlparse(url).hostname or '').lower()
    labels = host.split('.')
    if len(labels) >= 3 and labels[0] in ('mcp', 'api', 'www', 'app'):
        labels = labels[1:]
    if len(labels) >= 3 and len(labels[-1]) == 2 and labels[-2] in ('co', 'com', 'ne', 'or', 'go', 'ac'):
        return '.'.join(labels[-3:])
    return '.'.join(labels[-2:]) if len(labels) >= 2 else host


def looks_like_image_url(url):
    """画像のURLと分かるか(拡張子が画像、または Google の favicon 取得サービスのURL)。それ以外(サイトのURL・MCPサーバーのURL・クエリ付きの
    URLを含む)には、直接アクセスしない(クエリに鍵が付いている接続先URLを、勝手に呼ばないため)。"""
    u = urlparse(url)
    host = (u.hostname or '').lower()
    return (u.path.lower().rsplit('.', 1)[-1] in ('png', 'jpg', 'jpeg', 'gif', 'webp', 'ico')
            or (host.endswith('.gstatic.com') and u.path.startswith('/faviconV2')))


def download(url):
    """(画像のバイト列, 拡張子)。iconUrl がサイトのURLだけ(画像のURLでない)ときは、そのサイトのドメインの favicon を取る。取れなければ例外。"""
    if looks_like_image_url(url):
        data = fetch(url)
        ext = sniff(data)
        if ext:
            return data, ext
    dom = site_domain(url)
    if not dom:
        raise ValueError('no domain')
    data = fetch(FAVICON % quote('https://' + dom, safe=''))
    ext = sniff(data)
    if not ext:
        raise ValueError('not an image')
    return data, ext


def main(argv):
    if len(argv) < 2:
        print('usage: connectors_icons.py "<name>|<iconUrl>" ...')
        return 2
    snap = snapshot()
    if not snap:
        print('connectors.json がありません。先に connectors_save.py を実行してください')
        return 2
    names = {s['name'] for s in snap['servers']}
    got, skipped = {}, []
    ICON_DIR.mkdir(parents=True, exist_ok=True)
    for a in argv[1:][:MAX_ICONS]:
        name, _, url = a.rpartition('|')
        name = clean(name, 'other', 'unknown', None)['name']
        if name not in names or not url:
            skipped.append(name)
            continue
        try:
            data, ext = download(url.strip())
            fname = icon_stem(name) + '.' + ext
            (ICON_DIR / fname).write_bytes(data)
            got[name] = fname
        except Exception as e:  # 1枚の失敗で止めない(理由は、名前と短い種類だけ出す)
            skipped.append('%s(%s)' % (name, type(e).__name__))
    if got:
        o = json.loads(FILE.read_text(encoding='utf-8'))
        for s in o['servers']:
            if s['name'] in got:
                s['icon'] = got[s['name']]
        FILE.write_text(json.dumps(o, ensure_ascii=False), encoding='utf-8')
    print('icons_saved: %d / skipped: %d%s' % (len(got), len(skipped), (' ' + ', '.join(skipped)) if skipped else ''))
    return 0


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.exit(main(sys.argv))

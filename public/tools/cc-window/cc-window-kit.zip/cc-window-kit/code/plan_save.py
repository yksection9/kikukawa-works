"""plan_save.py - アプリの使用量リングと同じ値を、小窓用のファイルに保存する(取得時刻はここで付ける)。

使い方: python plan_save.py <プラン名> "<ラベル>|<使用%>|<リセット時刻(ISO)>" ...
値は Claude が会話の中で取得したもの。この窓自身は認証トークンを読まない。
保存先は token_usage.PLAN_FILE(設定フォルダ/cc-window-kit/plan_usage.json)。ツール自身の記録で、利用者のファイルではない。
"""
import json
import sys
import time

from token_usage import PLAN_FILE, _ts


def main(argv):
    if len(argv) < 3:
        print('usage: plan_save.py <plan> "<label>|<pct>|<resetsAt ISO>" ...')
        return 2
    wins = []
    for a in argv[2:]:
        label, pct, resets = a.split('|')
        _ts(resets)  # 形式の検査(おかしければここで例外)
        wins.append({'label': label, 'percentUsed': float(pct), 'resetsAt': resets})
    PLAN_FILE.parent.mkdir(parents=True, exist_ok=True)
    PLAN_FILE.write_text(json.dumps({'plan': argv[1], 'taken': time.time(), 'windows': wins}, ensure_ascii=False), encoding='utf-8')
    print('plan_saved: %d' % len(wins))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
